const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { scanUpload } = require('../utils/fileScanner');

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    const allowed = ['.pdf', '.jpg', '.jpeg', '.png'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowed.includes(ext)) cb(null, true);
    else cb(new Error('Invalid file type'));
  }
});

const getUploadsDir = () => path.join(__dirname, '..', 'uploads', 'job-applications');

const ensureUploadsDir = () => {
  const dir = getUploadsDir();
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
};

router.post('/', upload.single('file'), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ message: 'No file uploaded' });

    const scanResult = await scanUpload(req.file);
    if (!scanResult.clean) {
      return res.status(422).json({ message: scanResult.reason || 'File failed security scan' });
    }

    const dir = ensureUploadsDir();
    const ext = path.extname(req.file.originalname).toLowerCase();
    const filename = `${Date.now()}_${Math.random().toString(36).slice(2)}${ext}`;
    const filePath = path.join(dir, filename);

    await fs.promises.writeFile(filePath, req.file.buffer);

    const url = `${req.protocol}://${req.get('host')}/uploads/job-applications/${filename}`;
    res.json({ url, scanned: true });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
