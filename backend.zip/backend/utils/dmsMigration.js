const uuidv4 = require('./uuid');

const ALL_MODULES = [
  'overview', 'users', 'branches', 'departments', 'services', 'jobs', 'applications', 'testimonials',
  'general-inquiries', 'quote-requests', 'complaints', 'customers', 'invoices',
  'quotations', 'bookings', 'projects', 'staff', 'attendance', 'attendance-report',
  'payroll', 'transactions', 'financials', 'feedback-calls', 'audit',
  'verification-tracking', 'analytics', 'admin-logs', 'notifications',
  'documents-organizer', 'settings', 'profile'
];

const DEFAULT_DEPARTMENTS = [
  {
    name: 'Executive Board (HQ)',
    code: 'EXEC',
    description: 'Full administrative control of the DMS — Head Office',
    modules: ALL_MODULES
  },
  {
    name: 'Human Resources',
    code: 'HR',
    description: 'Manages payroll, attendance, staff profiles, jobs and applications',
    modules: ['overview', 'jobs', 'applications', 'staff', 'attendance', 'attendance-report', 'payroll', 'documents-organizer', 'profile']
  },
  {
    name: 'Finance & Accounts',
    code: 'FIN',
    description: 'Manages billing, invoices, quotations, transactions and financials',
    modules: ['overview', 'customers', 'invoices', 'quotations', 'transactions', 'financials', 'profile']
  },
  {
    name: 'Operations & Inquiries',
    code: 'OPS',
    description: 'Manages support tickets, complaints, bookings, projects, services and feedback',
    modules: ['overview', 'services', 'general-inquiries', 'quote-requests', 'complaints', 'bookings', 'projects', 'feedback-calls', 'profile']
  }
];

async function runDmsMigrations(db) {
  try {
    // 1. Create departments table
    await db.query(`
      CREATE TABLE IF NOT EXISTS departments (
        id CHAR(36) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        code VARCHAR(100) NOT NULL UNIQUE,
        description TEXT,
        modules JSON,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);

    // 1.5 Create branches table
    await db.query(`
      CREATE TABLE IF NOT EXISTS branches (
        id CHAR(36) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        code VARCHAR(100) NOT NULL UNIQUE,
        location VARCHAR(255),
        contact_email VARCHAR(255),
        contact_phone VARCHAR(50),
        status VARCHAR(20) DEFAULT 'active',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);

    // 2. Add department_id and branch_id to users if missing
    const [userCols] = await db.query('SHOW COLUMNS FROM users');
    const hasDeptId = userCols.some(c => c.Field === 'department_id');
    const hasCustomPerms = userCols.some(c => c.Field === 'custom_permissions');
    const hasBranchId = userCols.some(c => c.Field === 'branch_id');

    if (!hasDeptId) {
      await db.query('ALTER TABLE users ADD COLUMN department_id CHAR(36) NULL AFTER role');
    }
    if (!hasCustomPerms) {
      await db.query('ALTER TABLE users ADD COLUMN custom_permissions JSON NULL AFTER department_id');
    }
    if (!hasBranchId) {
      await db.query('ALTER TABLE users ADD COLUMN branch_id CHAR(36) NULL AFTER department_id');
    }

    // 3. Seed default departments if table is empty
    const [[{ count }]] = await db.query('SELECT COUNT(*) as count FROM departments');
    if (parseInt(count, 10) === 0) {
      for (const dept of DEFAULT_DEPARTMENTS) {
        await db.query(
          'INSERT INTO departments (id, name, code, description, modules) VALUES (?, ?, ?, ?, ?)',
          [uuidv4(), dept.name, dept.code, dept.description, JSON.stringify(dept.modules)]
        );
      }
      console.log('✅ [DMS] Default departments seeded');
    }

    console.log('✅ [DMS] Migrations complete');
  } catch (err) {
    console.error('⚠️ [DMS] Migration warning (non-fatal):', err.message);
  }
}

module.exports = { runDmsMigrations, ALL_MODULES };
